from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import IndustryaboutItem

class IndustryaboutSpider(CrawlSpider):

    name = "industryabout"
    
    start_urls = ["https://www.industryabout.com/country-territories-3/1902-indonesia/automotive-industry/29360-kayaba-bekasi-auto-component-plant"]

    def __init__(self, config_file = None, *args, **kwargs):                    
        super(IndustryaboutSpider, self).__init__(*args, **kwargs)   

        file = open("input.txt","r")

        links = []

        for link in file.readlines():
            links.append(link.replace("\n",""))

        self._url_list = links

        file.close()                                                             

    def start_requests(self):    

        for url in self._url_list:                                              
            yield Request(url = url, callback = self.list_page)
   
    def list_page(self,response):

        for links in response.css(".list-title a::attr(href)").extract():
            yield response.follow(links, callback = self.main_page)


    def main_page(self,response):

        product = IndustryaboutItem()

        product["Category"] = response.css(".category-name a::text").extract_first()

        product["Company"] = response.css(".item-page h2::text").extract_first()
        product["Company"] = product["Company"].strip()

        temp = response.css("div[itemprop= 'articleBody'] strong::text").extract()

        for info in temp:
            
            if "Type:" in info :
                product["Type"] = info.replace("Type:","")
            elif "Area:" in info:
                product["Area"] = info.replace("Area:","")
            elif "Products:" in info:
                product["Products"] = info.replace("Products:","")
            elif "Owner:" in info:
                product["Owner"] = info.replace("Owner:","")
            elif "Shareholders:" in info:
                product["Shareholders"] = info.replace("Shareholders:","")
            elif "Coordinates:" in info:
                product["Coordinates"] = info.replace("Coordinates:","")
            elif "Address:" in info:
                product["Address"] = info.replace("Address:","")
            elif "Phone:" in info:
                product["Phone"] = info.replace("Phone:","")

        product["Web"] = response.css("a[rel='nofollow']::attr(href)").extract_first()

        product["source"] = response.url


        yield product