# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class IndustryaboutItem(scrapy.Item):
    Category = scrapy.Field()
    Company = scrapy.Field()
    Type = scrapy.Field()
    Area = scrapy.Field()
    Products = scrapy.Field()
    Owner = scrapy.Field()
    Shareholders = scrapy.Field()
    Coordinates = scrapy.Field()
    Address = scrapy.Field()
    Phone = scrapy.Field()
    Web = scrapy.Field()
    source = scrapy.Field()
    pass
